import java.util.*;

public class Solucion {

    public static int[][] objetivo =
        new int[][] {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 0}};
    public static Estado estadoObjetivo = new Estado(new Puzzle(objetivo));

    public static Estado solucionar(Estado inicial) {
        List<Estado> abiertos = new ArrayList<>();
        Set<Estado> cerrados = new TreeSet<>();

        abiertos.add(inicial);

        while (abiertos.size() != 0) {
            Estado estado = abiertos.get(0);
            System.out.println(estado.getValor());
            if (estado.equals(estadoObjetivo)) {
                return estado;
            } else {
                List<Estado> estados = estado.generarEstados();
                for (Estado estadoGenerado : estados) {
                    if (!abiertos.contains(estadoGenerado) && !cerrados.contains(estadoGenerado)) {
                        abiertos.add(estadoGenerado);
                    }
                }
            }
            cerrados.add(estado);
            abiertos.remove(estado);
            Collections.sort(abiertos);
        }
        return null;
    }
}
