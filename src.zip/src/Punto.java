public class Punto {
    final int x, y;

    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
