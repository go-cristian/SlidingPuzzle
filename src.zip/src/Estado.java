import java.util.*;

public class Estado implements Comparable<Estado>, Comparator<Estado> {

    public static Estado con(String entrada) {
        String[] lineas = entrada.split("\\r?\\n");
        int[][] matriz = new int[Puzzle.SIZE][Puzzle.SIZE];
        for (int i = 0; i < lineas.length; i++) {
            String[] datos = lineas[i].split("-");
            for (int j = 0; j < datos.length; j++) {
                matriz[i][j] = Integer.parseInt(datos[j]);
            }
        }
        return new Estado(new Puzzle(matriz));
    }

    public enum DIRECCION {
        ARRIBA,
        ABAJO,
        DERECHA,
        IZQUIERDA,
    }


    private final Puzzle puzzle;
    private final int valor;

    private Queue<DIRECCION> path = new LinkedList<>();

    public Estado(Puzzle puzzle) {
        this.puzzle = puzzle;
        this.valor = calcluarValor();
    }

    private int calcluarValor() {
        int valor = 0;
        for (int i = 0; i < puzzle.getPuzzle().length; i++) {
            for (int j = 0; j < puzzle.getPuzzle()[i].length; j++) {
                int valorCelda = puzzle.getPuzzle()[i][j] - 1;
                if (valorCelda == -1) {
                    valorCelda = 15;
                }
                int valorEsperado = (i * Puzzle.SIZE) + j;
                valor += Math.abs(valorCelda - valorEsperado);
            }
        }
        return valor;
    }

    public List<Estado> generarEstados() {
        List<Estado> estados = new ArrayList<>();
        Punto cero = this.puzzle.getZero();

        if (cero.y - 1 >= 0)
            estados.add(Estado.con(this, DIRECCION.DERECHA));
        if (cero.x - 1 >= 0)
            estados.add(Estado.con(this, DIRECCION.ABAJO));
        if (cero.x + 1 < Puzzle.SIZE)
            estados.add(Estado.con(this, DIRECCION.ARRIBA));
        if (cero.y + 1 < Puzzle.SIZE)
            estados.add(Estado.con(this, DIRECCION.IZQUIERDA));

        return estados;
    }

    private static Estado con(Estado estado, DIRECCION direccion) {
        int[][] puzzleCopia = new int[estado.getPuzzle().getPuzzle().length][];
        for (int i = 0; i < estado.getPuzzle().getPuzzle().length; i++) {
            puzzleCopia[i] = estado.getPuzzle().getPuzzle()[i].clone();
        }

        Punto cero = estado.getPuzzle().getZero();

        Punto puntoSwap;
        switch (direccion) {
            case DERECHA:
                puntoSwap = new Punto(cero.x, cero.y - 1);
                break;
            case IZQUIERDA:
                puntoSwap = new Punto(cero.x, cero.y + 1);
                break;
            case ABAJO:
                puntoSwap = new Punto(cero.x - 1, cero.y);
                break;
            case ARRIBA:
                puntoSwap = new Punto(cero.x + 1, cero.y);
                break;
            default:
                throw new IllegalStateException("no es posible realizar este movimiento");
        }
        puzzleCopia[cero.x][cero.y] = puzzleCopia[puntoSwap.x][puntoSwap.y];
        puzzleCopia[puntoSwap.x][puntoSwap.y] = 0;
        Estado nuevoEstado = new Estado(new Puzzle(puzzleCopia));
        nuevoEstado.addToPath(estado.getPath());
        nuevoEstado.addToPath(direccion);
        return nuevoEstado;
    }

    public Puzzle getPuzzle() {
        return puzzle;
    }

    public int getValor() {
        return valor;
    }

    @Override public int compareTo(Estado o) {
        return ((Integer) getValor()).compareTo(o.getValor());
    }

    @Override public int compare(Estado o1, Estado o2) {
        return ((Integer) o1.getValor()).compareTo(o2.getValor());
    }

    @Override public boolean equals(Object obj) {
        if (obj instanceof Estado) {
            int[][] puzzle = getPuzzle().getPuzzle();
            int[][] puzzleComparador = ((Estado) obj).getPuzzle().getPuzzle();
            for (int i = 0; i < puzzle.length; i++) {
                for (int j = 0; j < puzzle[i].length; j++) {
                    if (puzzle[i][j] != puzzleComparador[i][j]) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
        return true;
    }

    public Queue<DIRECCION> getPath() {
        return path;
    }

    public void addToPath(DIRECCION direccion) {
        path.add(direccion);
    }

    private void addToPath(Queue<DIRECCION> path) {
        this.path.addAll(path);
    }
}
